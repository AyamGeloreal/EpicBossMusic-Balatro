--- STEAMODDED HEADER
--- MOD_NAME: Epic Boss Music byJINANS
--- MOD_ID: EpicBossMusic
--- PREFIX: JBM
--- MOD_AUTHOR: [Jinan]
--- MOD_DESCRIPTION: mod ini menambahkan epic music saat boss blind
SMODS.Sound({
    vol = 0.6,
    pitch = 1,
    key = "music_boss_funk",
    path = "BossFunk.ogg",
    select_music_track = function()
        return (G.GAME and G.GAME.blind and (G.GAME.blind.config.blind.boss and not G.GAME.blind.config.blind.boss.showdown)) and 1 or false
    end,
})

SMODS.Sound({
    vol = 0.6,
    pitch = 1,
    key = "music_flush_five",
    path = "FLUSHFIVE.ogg",
    select_music_track = function()
        return (G.GAME and G.GAME.blind and (G.GAME.blind.config.blind.boss and G.GAME.blind.config.blind.boss.showdown)) and 2 or false
    end,
})
